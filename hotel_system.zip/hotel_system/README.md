# Proyecto: Sistema de Reservas de Hotel

Este proyecto es un sistema de gestión de reservas de hotel con diferentes roles: administrador, gerente, recepcionista, cliente y proveedor.

## Requisitos:
- PHP 7.4 o superior
- MySQL
- Servidor local como XAMPP, WAMP, Laragon, etc.

## Instalación:
1. Coloca el proyecto en la carpeta `htdocs` o `www` de tu servidor local.
2. Crea la base de datos usando el archivo `sql/schema.sql`.
3. Configura el archivo `includes/db.php` si es necesario.
4. Accede al sistema en `http://localhost/hotel_system/public/` para probarlo.

## Roles:
- **Administrador**: Gestiona usuarios y habitaciones.
- **Gerente del hotel**: Gestiona habitaciones y precios.
- **Recepcionista**: Hace reservas para clientes.
- **Cliente**: Puede hacer reservas.
- **Proveedor**: Ofrece suministros al hotel.
