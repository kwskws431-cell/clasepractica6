<?php
if (session_status() === PHP_SESSION_NONE) session_start();

function require_login() {
    if (!isset($_SESSION['user'])) {
        header('Location: /hotel_system/public/login.php');
        exit;
    }
}

function current_user() {
    return $_SESSION['user'] ?? null;
}

function check_role($roles) {
    $user = current_user();
    if (!$user) return false;
    if (is_string($roles)) $roles = [$roles];
    return in_array($user['role_name'], $roles);
}