<?php
// Formulario de registro de usuario
require_once __DIR__ . '/../includes/db.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $role_id = 4; // Rol Cliente

    // Verificar si el email ya existe
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        $error = 'El email ya está registrado.';
    } else {
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role_id) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $email, $passwordHash, $role_id]);
        header('Location: /hotel_system/public/login.php');
        exit;
    }
}

require_once __DIR__ . '/../includes/header.php';
?>
<h2>Registrarse</h2>
<form method="post">
  <input name="name" type="text" placeholder="Nombre completo" required>
  <input name="email" type="email" placeholder="Email" required>
  <input name="password" type="password" placeholder="Contraseña" required>
  <button>Registrarse</button>
</form>
<?php if ($error): ?><p><?= htmlspecialchars($error) ?></p><?php endif; ?>
<?php require_once __DIR__ . '/../includes/footer.php'; 