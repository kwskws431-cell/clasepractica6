<?php
// public/bookings.php
require_once __DIR__ . '/../includes/db.php';  // Incluir la conexión a la base de datos
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user'])) {
    header('Location: /hotel_system/public/login.php');
    exit;
}

$user_id = $_SESSION['user']['id'];  // Obtener el ID del usuario desde la sesión

// Obtener las reservas del usuario logueado
$stmt = $pdo->prepare("SELECT bookings.*, rooms.room_number, rooms.room_type, rooms.room_price 
                       FROM bookings 
                       JOIN rooms ON bookings.room_id = rooms.id 
                       WHERE bookings.user_id = ?");
$stmt->execute([$user_id]);
$bookings = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';  // Incluir el encabezado
?>

<div class="container mt-5">
    <h2 class="text-center mb-4">Mis Reservas</h2>

    <!-- Mostrar error si no hay reservas -->
    <?php if (count($bookings) === 0): ?>
        <p class="text-center">No tienes reservas en este momento.</p>
    <?php else: ?>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Habitación</th>
                    <th>Tipo</th>
                    <th>Fecha de Entrada</th>
                    <th>Fecha de Salida</th>
                    <th>Precio Total</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($bookings as $booking): ?>
                    <tr>
                        <td><?= htmlspecialchars($booking['room_number']) ?></td>
                        <td><?= htmlspecialchars($booking['room_type']) ?></td>
                        <td><?= htmlspecialchars($booking['check_in_date']) ?></td>
                        <td><?= htmlspecialchars($booking['check_out_date']) ?></td>
                        <td>$<?= number_format($booking['room_price'], 2) ?></td>
                        <td>
                            <?php if ($booking['check_out_date'] < date('Y-m-d')): ?>
                                <span class="badge bg-secondary">Finalizada</span>
                            <?php else: ?>
                                <span class="badge bg-primary">En Proceso</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php';  // Incluir el pie de página ?>
