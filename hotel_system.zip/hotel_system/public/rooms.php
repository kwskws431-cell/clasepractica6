<?php
// public/rooms.php
require_once __DIR__ . '/../includes/db.php';  // Incluir la conexión a la base de datos
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user'])) {
    header('Location: /hotel_system/public/login.php');
    exit;
}

// Obtener las habitaciones disponibles
$stmt = $pdo->query("SELECT * FROM rooms WHERE is_available = 1");
$rooms = $stmt->fetchAll();

$error = '';  // Variable para manejar posibles errores

// Si se ha enviado un formulario de reserva
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $room_id = $_POST['room_id'];  // Obtener el ID de la habitación seleccionada
    $check_in_date = $_POST['check_in_date'];  // Fecha de entrada
    $check_out_date = $_POST['check_out_date'];  // Fecha de salida

    // Obtener el ID del usuario desde la sesión
    $user_id = $_SESSION['user']['id'];

    // Verificar que las fechas no sean menores que la fecha actual
    if (strtotime($check_in_date) < strtotime(date('Y-m-d'))) {
        $error = "La fecha de entrada no puede ser anterior a la fecha actual.";
    } elseif (strtotime($check_out_date) <= strtotime($check_in_date)) {
        $error = "La fecha de salida debe ser posterior a la fecha de entrada.";
    } else {
        // Insertar la reserva en la base de datos
        $stmt = $pdo->prepare("INSERT INTO bookings (user_id, room_id, booking_date, check_in_date, check_out_date) 
                               VALUES (?, ?, NOW(), ?, ?)");
        $stmt->execute([$user_id, $room_id, $check_in_date, $check_out_date]);

        // Marcar la habitación como no disponible
        $stmt = $pdo->prepare("UPDATE rooms SET is_available = 0 WHERE id = ?");
        $stmt->execute([$room_id]);

        // Redirigir al usuario a su panel de reservas
        header('Location: /hotel_system/public/bookings.php');
        exit;
    }
}

require_once __DIR__ . '/../includes/header.php';  // Incluir el encabezado
?>

<div class="container mt-5">
    <h2 class="text-center mb-4">Habitaciones disponibles</h2>

    <!-- Mostrar error si ocurre -->
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Formulario para seleccionar una habitación y hacer una reserva -->
    <?php if (count($rooms) > 0): ?>
        <form method="POST" action="" class="row g-3">
            <?php foreach ($rooms as $room): ?>
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/300" class="card-img-top" alt="Habitación">
                        <div class="card-body">
                            <h5 class="card-title">Habitación <?= htmlspecialchars($room['room_number']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($room['room_type']) ?></p>
                            <p class="card-text">Precio: $<?= number_format($room['room_price'], 2) ?></p>
                            
                            <!-- Selección de fechas -->
                            <label for="check_in_date_<?= $room['id'] ?>">Fecha de Entrada:</label>
                            <input type="date" class="form-control" name="check_in_date" id="check_in_date_<?= $room['id'] ?>" required>
                            
                            <label for="check_out_date_<?= $room['id'] ?>">Fecha de Salida:</label>
                            <input type="date" class="form-control" name="check_out_date" id="check_out_date_<?= $room['id'] ?>" required>
                            
                            <!-- Botón para reservar la habitación -->
                            <button type="submit" name="room_id" value="<?= $room['id'] ?>" class="btn btn-primary mt-3">Reservar</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </form>
    <?php else: ?>
        <p class="text-center">No hay habitaciones disponibles en este momento.</p>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php';  // Incluir el pie de página ?>
