<?php
// Página de inicio (habitaciones disponibles)
// Conéctate a la base de datos y muestra habitaciones disponibles
require_once __DIR__ . '/../includes/db.php';

$stmt = $pdo->query("SELECT * FROM rooms WHERE is_available = 1");
$rooms = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<h1>Bienvenido al Sistema de Reservas de Hotel</h1>
<h3>Habitaciones disponibles:</h3>
<ul>
  <?php foreach ($rooms as $room): ?>
    <li>Habitación <?= htmlspecialchars($room['room_number']) ?> - <?= htmlspecialchars($room['room_type']) ?> - $<?= number_format($room['room_price'], 2) ?></li>
  <?php endforeach; ?>
</ul>
<?php require_once __DIR__ . '/../includes/footer.php'; 