<?php
// public/dashboard.php
require_once __DIR__ . '/../includes/db.php';  // Incluir la conexión a la base de datos
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user'])) {
    header('Location: /hotel_system/public/login.php');
    exit;
}

$user = $_SESSION['user'];  // Datos del usuario logueado

require_once __DIR__ . '/../includes/header.php';  // Incluir el encabezado
?>

<div class="container mt-5">
    <h2 class="text-center">Bienvenido, <?= htmlspecialchars($user['username']) ?> (<?= htmlspecialchars($user['role_name']) ?>)</h2>

    <div class="row mt-4">
        <!-- Menú de opciones según el rol del usuario -->
        <?php if ($user['role_id'] == 1): // Administrador ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Administrar usuarios</h5>
                        <p class="card-text">Gestiona todos los usuarios del sistema.</p>
                        <a href="/hotel_system/public/manage_users.php" class="btn btn-primary">Gestionar usuarios</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Administrar habitaciones</h5>
                        <p class="card-text">Añadir, eliminar y modificar habitaciones.</p>
                        <a href="/hotel_system/public/manage_rooms.php" class="btn btn-primary">Gestionar habitaciones</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($user['role_id'] == 2): // Gerente del hotel ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Ver reservas</h5>
                        <p class="card-text">Ver las reservas realizadas por los clientes.</p>
                        <a href="/hotel_system/public/bookings.php" class="btn btn-primary">Ver reservas</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Gestionar habitaciones</h5>
                        <p class="card-text">Añadir y modificar habitaciones y precios.</p>
                        <a href="/hotel_system/public/manage_rooms.php" class="btn btn-primary">Gestionar habitaciones</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($user['role_id'] == 3): // Recepcionista ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Reservar habitaciones</h5>
                        <p class="card-text">Realizar reservas para los clientes.</p>
                        <a href="/hotel_system/public/rooms.php" class="btn btn-primary">Ver habitaciones</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Mis reservas</h5>
                        <p class="card-text">Ver las reservas realizadas por los clientes.</p>
                        <a href="/hotel_system/public/bookings.php" class="btn btn-primary">Ver reservas</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($user['role_id'] == 4): // Cliente ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Ver habitaciones</h5>
                        <p class="card-text">Consulta las habitaciones disponibles y realiza reservas.</p>
                        <a href="/hotel_system/public/rooms.php" class="btn btn-primary">Ver habitaciones</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Mis reservas</h5>
                        <p class="card-text">Consulta tus reservas realizadas.</p>
                        <a href="/hotel_system/public/bookings.php" class="btn btn-primary">Mis reservas</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($user['role_id'] == 5): // Proveedor ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Gestionar suministros</h5>
                        <p class="card-text">Ofrecer suministros para el hotel.</p>
                        <a href="/hotel_system/public/supplies.php" class="btn btn-primary">Ver suministros</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php';  // Incluir el pie de página ?>
