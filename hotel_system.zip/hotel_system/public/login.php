<?php
// public/login.php
require_once __DIR__ . '/../includes/db.php'; // Incluir conexión a la base de datos
session_start();  // Iniciar la sesión
$error = '';  // Variable para mostrar errores

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');  // Obtener el email del formulario
    $password = $_POST['password'] ?? '';  // Obtener la contraseña

    // Consulta para verificar si el email existe en la base de datos
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Verificar si el usuario existe y si la contraseña es correcta
    if ($user && password_verify($password, $user['password'])) {
        // Obtener el nombre del rol
        $stmt2 = $pdo->prepare("SELECT name FROM roles WHERE id = ?");
        $stmt2->execute([$user['role_id']]);
        $role_name = $stmt2->fetchColumn();

        // Almacenar los datos del usuario en la sesión
        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'role_id' => $user['role_id'],
            'role_name' => $role_name
        ];

        // Redirigir al dashboard según el rol
        header('Location: /hotel_system/public/dashboard.php');
        exit;
    } else {
        // Si las credenciales son incorrectas
        $error = "Credenciales inválidas.";
    }
}

require_once __DIR__ . '/../includes/header.php'; // Incluir el encabezado común
?>

<h2>Iniciar sesión</h2>

<!-- Formulario de login -->
<form method="post" class="mt-3">
    <input class="form-control mb-2" name="email" type="email" placeholder="Email" required>
    <input class="form-control mb-2" name="password" type="password" placeholder="Contraseña" required>
    <button class="btn btn-primary">Entrar</button>
</form>

<!-- Mostrar el error si las credenciales son inválidas -->
<?php if ($error): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?> <!-- Incluir pie de página común -->
